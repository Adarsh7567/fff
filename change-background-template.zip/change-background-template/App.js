import React, { Component } from 'react';
import { View, Button, Alert } from 'react-native';

export default class App extends Component { 
  constructor(props) {
    super(props);
   
    //set the intiial state as yellow color
    this.state = {  
    
      bgColor: "yellow"
    
  }}
  

  boxClick2 = (e) => {
    this.setState({
      bgColor: "red"

    })}

    boxClick2 = (e) => {
    this.setState({
      bgColor: "green"
    })
  }

  render() {
    return (
     <button 
   
          style={{backgroundColor: this.state.bgColor, width: "200px", height:"200px"
}}
           onMouseEnter={this.boxClick}
            onMouseLeave={this.boxClick2}>Click Me!</button>
    );
  }
}